//
//  ContentView.swift
//  tune-mosaic
//
//  Created by Kaan Aras on 2.11.2023.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView {
            ZStack {
                Color.spotifyGreen
                    .edgesIgnoringSafeArea(.all)
                
                VStack {
                    Text("tune-mosaic")
                        .font(.largeTitle)
                        .fontWeight(.heavy)
                        .padding(.bottom, 20)
                    
                    NavigationLink(destination: LoginView()) {
                        Text("Login")
                            .padding()
                            .background(Color.black)
                            .foregroundColor(Color.spotifyGreen)
                            .cornerRadius(8)
                    }
                    .padding(.bottom, 10) // Padding for visual spacing
                    
                    NavigationLink(destination: RegisterView()) {
                        Text("Register")
                            .padding()
                            .background(Color.black)
                            .foregroundColor(Color.spotifyGreen)
                            .cornerRadius(8)
                    }
                    .padding(.top, 10)
                }
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
