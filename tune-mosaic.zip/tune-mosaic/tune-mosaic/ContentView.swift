import SwiftUI

struct ContentView: View {
    @State private var isLoggedIn = false
    let sampleUser = UserProfile(id: "1", username: "SampleUser", profilePicture: "e73117c2-0ca1-46ed-9bfd-946766afefa7")

    var body: some View {
        NavigationView {
            if isLoggedIn {
                // If the user is logged in, show the MainFeedView
                MainFeedView(currentUserProfile: sampleUser)
            } else {
                // If the user is not logged in, show the login and register options
                ZStack {
                    Color.spotifyGreen
                        .edgesIgnoringSafeArea(.all)
                    
                    VStack {
                        Text("tune-mosaic")
                            .font(.largeTitle)
                            .fontWeight(.heavy)
                            .padding(.bottom, 20)
                        
                        NavigationLink(destination: LoginView(isLoggedIn: $isLoggedIn)) {
                            Text("Login")
                                .padding()
                                .background(Color.black)
                                .foregroundColor(Color.spotifyGreen)
                                .cornerRadius(8)
                        }
                        .padding(.bottom, 10)
                        
                        NavigationLink(destination: RegisterView(isLoggedIn: $isLoggedIn)) {
                            Text("Register")
                                .padding()
                                .background(Color.black)
                                .foregroundColor(Color.spotifyGreen)
                                .cornerRadius(8)
                        }
                        .padding(.top, 10)
                    }
                }
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
