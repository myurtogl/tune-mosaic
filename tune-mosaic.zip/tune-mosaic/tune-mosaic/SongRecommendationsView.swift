//
//  SongRecommendationsView.swift
//  tune-mosaic
//
//  Created by Kaan Aras on 11.12.2023.
//

import SwiftUI
import FirebaseAuth
import FirebaseDatabase

struct SongRecommendationsView: View {
    @State private var recommendedSongs: [SongRecommendation] = []
    @State private var Songs: [Song] = []
    @State private var ratedSongs: [Song] = []
    
    var body: some View {
        List {
            ForEach(recommendedSongs, id: \.id) { song in
                VStack(alignment: .leading) {
                    Text(song.Name)
                        .font(.headline)
                    Text(song.Artist)
                        .font(.subheadline)
                    // Include other song details and rating stars if needed
                }
            }
        }
        .onAppear(perform: loadUnratedSongs)
        .navigationBarTitle("Song Recommendations", displayMode: .inline)
    }
    
    private func updateRating(for songId: String, with rating: Int) {
        guard let user = Auth.auth().currentUser else {
            print("No authenticated user found")
            return
        }

        let userId = user.uid
        let ref = Database.database().reference(withPath: "users/\(userId)/songs/\(songId)")
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd.MM.yy"
        let dateOfRatingString = dateFormatter.string(from: Date())

        ref.updateChildValues(["rating": rating, "dateOfRating": dateOfRatingString]) { error, _ in
            if let error = error {
                print("Error updating rating: \(error.localizedDescription)")
                return
            }
            
            // Update the local array
            if let index = self.Songs.firstIndex(where: { $0.id == songId }) {
                DispatchQueue.main.async {
                    self.Songs[index].rating = rating
                    self.Songs[index].dateOfRating = dateOfRatingString
                }
            }
        }
    }
    
    
    private func loadUnratedSongs() {
        guard let user = Auth.auth().currentUser else {
            print("No authenticated user found")
            return
        }

        let userId = user.uid
        let ref = Database.database().reference(withPath: "users/\(userId)/songs")

        ref.observeSingleEvent(of: .value) { snapshot in
            var newSongs: [Song] = []

            for child in snapshot.children {
                if let snapshot = child as? DataSnapshot,
                   let songDict = snapshot.value as? [String: AnyObject],
                   let name = songDict["Name"] as? String,
                   let artist = songDict["Artist"] as? String,
                   let album = songDict["Album"] as? String,
                   let releaseDate = songDict["Release Date"] as? String,
                   let durationMs = songDict["Duration (ms)"] as? Int,
                   let genre = songDict["Genre"] as? String,
                   let danceability = songDict["Danceability"] as? Double,
                   let energy = songDict["Energy"] as? Double,
                   let valence = songDict["Valence"] as? Double,
                   let rating = songDict["rating"] as? Int,
                   let dateOfRating = songDict["dateOfRating"] as? String,
                   rating == 0 { // Only add songs with a rating greater than 0
                    
                    let previewURL = songDict["Preview URL"] as? String

                    let song = Song(
                        id: snapshot.key,
                        name: name,
                        artist: artist,
                        album: album,
                        releaseDate: releaseDate,
                        durationMs: durationMs,
                        previewURL: previewURL,
                        genre: genre,
                        danceability: danceability,
                        energy: energy,
                        valence: valence,
                        rating: rating,
                        dateOfRating: dateOfRating
                    )
                    newSongs.append(song)
                }
            }

            DispatchQueue.main.async {
                self.Songs = newSongs.sorted { $0.name < $1.name } // Sort songs by name
            }
        }
    }
}



struct SongRecommendationsView_Previews: PreviewProvider {
    static var previews: some View {
        SongRecommendationsView()
    }
}

