import SwiftUI
import FirebaseAuth
import FirebaseDatabase
import Combine

struct SongRecommendationsView: View {
    @State private var recommendedSongs: [MusicPost] = []
    
    var body: some View {
            List {
                ForEach(recommendedSongs) { song in
                    VStack(alignment: .leading) {
                        Text(song.songName)
                            .font(.headline)
                        Text(song.artistName)
                            .font(.subheadline)
                        HStack {
                            ForEach(1...5, id: \.self) { number in
                                Image(systemName: song.rating >= number ? "star.fill" : "star")
                                    .foregroundColor(song.rating >= number ? .yellow : .gray)
                                    .onTapGesture {
                                        updateRating(for: song.id, with: number)
                                    }
                            }
                        }
                    }
                }
            }
            .onAppear(perform: loadRecommendedSongs)
            .navigationBarTitle("Song Recommendations", displayMode: .inline)
        }
    
    private func updateRating(for songId: String, with rating: Int) {
        guard let userId = Auth.auth().currentUser?.uid else {
            print("No authenticated user found")
            return
        }
        
        // Prepare the URL and request
        guard let url = URL(string: "http://127.0.0.1:5000/rate-song") else { return }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        // Prepare the JSON data to send
        let postData: [String: Any] = [
            "user_id": userId,
            "song_id": songId,
            "rating": rating
        ]
        
        // Convert postData to JSON
        guard let jsonData = try? JSONSerialization.data(withJSONObject: postData) else { return }
        request.httpBody = jsonData
        
        // Perform the request
        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Error sending request: \(error)")
                return
            }
            
            // Check the response and parse JSON
            guard let data = data,
                  let response = try? JSONDecoder().decode(ServerResponse.self, from: data) else {
                print("Invalid response or data")
                return
            }
            
            if response.success {
                // Success - remove the song from the local list
                DispatchQueue.main.async {
                    if let index = self.recommendedSongs.firstIndex(where: { $0.id == songId }) {
                        self.recommendedSongs.remove(at: index)
                    }
                }
            } else {
                print("Server responded with an error: \(response.message)")
            }
        }.resume()
    }

    private func loadRecommendedSongs() {
        guard let userId = Auth.auth().currentUser?.uid else {
            print("No authenticated user found")
            return
        }

        let recommendedSongsRef = Database.database().reference(withPath: "users/\(userId)/recommended-songs")
        
        recommendedSongsRef.observeSingleEvent(of: .value) { snapshot in
            var newSongs: [MusicPost] = []
            
            for childSnapshot in snapshot.children.allObjects as? [DataSnapshot] ?? [] {
                if let songDict = childSnapshot.value as? [String: AnyObject],
                   let name = songDict["Name"] as? String,
                   let artist = songDict["Artist"] as? String,
                   let rating = songDict["rating"] as? Int {
                    let song = MusicPost(
                        id: childSnapshot.key,
                        user: UserProfile(id: "", username: "", email: "", name: "", surname: "", profilePicture: ""),
                        songName: name,
                        artistName: artist,
                        rating: rating
                    )
                    newSongs.append(song)
                }
            }

            DispatchQueue.main.async {
                self.recommendedSongs = newSongs
            }
        }
    }
}

struct SongRecommendationsView_Previews: PreviewProvider {
    static var previews: some View {
        SongRecommendationsView()
    }
}

// Define the structure for your server response
struct ServerResponse: Codable {
    let success: Bool
    let message: String
}
