import SwiftUI
import FirebaseAuth
import FirebaseDatabase

struct GroupsView: View {
    @State private var groups: [Group] = []
    @State private var showingCreateGroupView = false
    @State private var friends: [UserProfile] = []

    var body: some View {
        NavigationView {
            List {
                ForEach(groups, id: \.id) { group in
                    NavigationLink(destination: GroupDetailView(group: group, friends: friends)) {
                        GroupRow(group: group)
                    }
                }
            }
            .navigationBarTitle("Groups")
            .navigationBarItems(
                trailing: Button(action: {
                    showingCreateGroupView = true
                }) {
                    Image(systemName: "plus")
                }
            )
            .onAppear(perform: {
                loadGroups()
                loadFriends()
            })
            .sheet(isPresented: $showingCreateGroupView) {
                CreateGroupView(friends: friends, onGroupCreated: {
                    self.loadGroups() // Refresh the groups list
                })
            }

        }
    }

    private func loadGroups() {
        guard let _ = Auth.auth().currentUser?.uid else {
            print("No authenticated user found")
            return
        }
        
        let groupsRef = Database.database().reference(withPath: "groups")
        groupsRef.observeSingleEvent(of: .value) { snapshot in
            var newGroups = [Group]()
            
            for childSnapshot in snapshot.children.allObjects as? [DataSnapshot] ?? [] {
                if let groupDict = childSnapshot.value as? [String: AnyObject],
                   let name = groupDict["Name"] as? String,
                   let admin = groupDict["Admin"] as? String {
                    var members = [UserProfile]() // Initialize an empty array for member profiles

                    // Check if the Members node exists and is a dictionary
                    if let membersNode = groupDict["Members"] as? [String: [String: String]] {
                        for (_, memberDetails) in membersNode {
                            if let username = memberDetails["Name"] {
                                // Here, add the logic to create a UserProfile for each member.
                                let userProfile = UserProfile(
                                    id: "", // Use appropriate member ID if available.
                                    username: username,
                                    email: "", // Populate with actual data if available.
                                    name: "", // Populate with actual data if available.
                                    surname: "", // Populate with actual data if available.
                                    profilePicture: "" // Populate with actual data if available.
                                )
                                members.append(userProfile)
                            }
                        }
                    }

                    // Always include the admin as a member
                    let adminProfile = UserProfile(id: admin, username: "Admin", email: "", name: "", surname: "", profilePicture: "")
                    if !members.contains(where: { $0.id == admin }) {
                        members.insert(adminProfile, at: 0)
                    }

                    let group = Group(id: childSnapshot.key, name: name, admin: admin, members: members)
                    newGroups.append(group)
                }
            }
            
            DispatchQueue.main.async {
                self.groups = newGroups.sorted(by: { $0.name.lowercased() < $1.name.lowercased() })
            }
        }
    }





    private func loadFriends() {
        guard let currentUserId = Auth.auth().currentUser?.uid else {
            print("No authenticated user found")
            return
        }

        let friendsRef = Database.database().reference(withPath: "users/\(currentUserId)/friends")
        friendsRef.observeSingleEvent(of: .value) { snapshot in
            var newFriends: [UserProfile] = []

            let userFriends = snapshot.value as? [String: Any] ?? [:]
            let usersRef = Database.database().reference(withPath: "users")

            usersRef.observeSingleEvent(of: .value) { snapshot in
                for (friendId, _) in userFriends {
                    if let friendData = snapshot.childSnapshot(forPath: friendId).value as? [String: AnyObject],
                       let username = friendData["username"] as? String,
                       let email = friendData["email"] as? String,
                       let name = friendData["name"] as? String,
                       let surname = friendData["surname"] as? String {
                        let friend = UserProfile(
                            id: friendId,
                            username: username,
                            email: email,
                            name: name,
                            surname: surname,
                            profilePicture: friendData["profilePicture"] as? String ?? ""
                        )
                        newFriends.append(friend)
                    }
                }

                DispatchQueue.main.async {
                    self.friends = newFriends
                }
            }
        }
    }

    private func fetchUserProfiles(memberIds: [String], completion: @escaping ([UserProfile]) -> Void) {
        // Initialize an array to hold the fetched user profiles
        var userProfiles: [UserProfile] = []
        
        // Create a dispatch group to synchronize the completion of asynchronous fetch requests
        let fetchGroup = DispatchGroup()
        
        // Iterate through the list of member IDs
        for memberId in memberIds {
            // Enter the group for each asynchronous fetch request
            fetchGroup.enter()
            
            // Reference to the user's profile in the database
            let userRef = Database.database().reference(withPath: "users/\(memberId)")
            
            // Observe a single event to fetch the user data
            userRef.observeSingleEvent(of: .value, with: { snapshot in
                print("User profile snapshot: \(snapshot)") // Debug: Print the snapshot to check for user data
                // Parse the snapshot to create a UserProfile
                if let userDict = snapshot.value as? [String: Any],
                   let username = userDict["username"] as? String,
                   let email = userDict["email"] as? String,
                   let name = userDict["name"] as? String,
                   let surname = userDict["surname"] as? String,
                   let profilePicture = userDict["profilePicture"] as? String {
                    
                    let userProfile = UserProfile(id: memberId, username: username, email: email, name: name, surname: surname, profilePicture: profilePicture)
                    userProfiles.append(userProfile)
                }
                // Signal that this particular fetch request is complete
                fetchGroup.leave()
            }) { error in
                print("Error fetching user profiles: \(error.localizedDescription)") // Debug: Print any errors
                print(error.localizedDescription)
                // If there is an error, we still need to leave the group
                fetchGroup.leave()
            }
        }
        
        // Once all fetch requests have completed, call the completion handler
        fetchGroup.notify(queue: .main) {
            completion(userProfiles)
        }
    }

    
    
}

// MARK: - GroupRow
struct GroupRow: View {
    var group: Group

    var body: some View {
        HStack {
            Text(group.name)
                .foregroundColor(.black)
            Spacer()
            // Use the members array count
            Text("\(group.members.count) members")
                .foregroundColor(.gray)
        }
    }
}

// MARK: - CreateGroupView
struct CreateGroupView: View {
    @State private var createdGroupId: String?
    @State private var groupName: String = ""
    @State private var selectedFriends: [UserProfile] = []
    @Environment(\.presentationMode) var presentationMode
    var friends: [UserProfile]
    var onGroupCreated: () -> Void

    var body: some View {
            NavigationView {
                Form {
                    Section {
                        TextField("Group Name", text: $groupName)
                    }

                    // If you need to show selected members in this section, ensure 'group' is passed correctly
                    Section(header: Text("Members")) {
                        ForEach(selectedFriends, id: \.id) { member in
                            Text(member.username) // This will show the selected friends
                        }
                    }

                    Section(header: Text("Add Friends")) {
                        ForEach(friends, id: \.id) { friend in
                            Button(action: {
                                self.addOrRemoveFriend(friend: friend)
                            }) {
                                HStack {
                                    Text(friend.username)
                                    Spacer()
                                    if selectedFriends.contains(where: { $0.id == friend.id }) {
                                        Image(systemName: "checkmark")
                                    }
                                }
                            }
                            .foregroundColor(.black)
                        }
                    }

                    Section {
                        Button("Create Group") {
                            self.createGroup()
                        }
                    }
                }
                .navigationBarTitle("Create Group")
                .navigationBarItems(trailing: Button("Done") {
                    self.presentationMode.wrappedValue.dismiss()
                })
            }
        }
    
    private func addOrRemoveFriend(friend: UserProfile) {
        if let index = selectedFriends.firstIndex(where: { $0.id == friend.id }) {
            selectedFriends.remove(at: index)
        } else {
            selectedFriends.append(friend)
        }
    }

    private func createGroup() {
        guard let userId = Auth.auth().currentUser?.uid, !groupName.isEmpty else {
            print("No authenticated user found or group name is empty")
            return
        }
        
        let url = URL(string: "http://127.0.0.1:5000/create-group")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.httpBody = try? JSONSerialization.data(withJSONObject: [
            "admin_id": userId,
            "group_name": groupName,
            "member_ids": selectedFriends.map { $0.id }
        ])
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                DispatchQueue.main.async {
                    print("Error creating group: \(error.localizedDescription)")
                }
                return
            }
            
            guard let httpResponse = response as? HTTPURLResponse else {
                DispatchQueue.main.async {
                    print("Unexpected response from server")
                }
                return
            }
            
            
            if (200...299).contains(httpResponse.statusCode) {
                            // Try to decode the response to get the group ID
                            if let data = data,
                               let jsonResponse = try? JSONDecoder().decode(CreateGroupResponse.self, from: data) {
                                // Save the created group ID
                                DispatchQueue.main.async {
                                    self.createdGroupId = jsonResponse.group_id
                                    // Call addMembersToGroup for each selected friend
                                    self.selectedFriends.forEach { friend in
                                        self.addMemberToGroup(friendId: friend.id)
                                    }
                                }
                            }
            } else {
                // Server responded with an error
                DispatchQueue.main.async {
                    print("Server error with status code: \(httpResponse.statusCode)")
                }
            }
        }.resume()
    }
    private func addMemberToGroup(friendId: String) {
            guard let groupId = self.createdGroupId else { return }

            let url = URL(string: "http://127.0.0.1:5000/add-member")!
            var request = URLRequest(url: url)
            request.httpMethod = "POST"
            request.httpBody = try? JSONSerialization.data(withJSONObject: [
                "group_id": groupId,
                "admin_id": Auth.auth().currentUser?.uid ?? "",
                "new_member_id": friendId
            ])
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")

            // Perform the request to add a member to the group
            URLSession.shared.dataTask(with: request) { _, response, error in
                if let error = error {
                    DispatchQueue.main.async {
                        print("Error adding member to group: \(error.localizedDescription)")
                    }
                    return
                }

                if let httpResponse = response as? HTTPURLResponse, (200...299).contains(httpResponse.statusCode) {
                    DispatchQueue.main.async {
                        // Successfully added member to group
                        // Update any necessary state here
                    }
                } else {
                    DispatchQueue.main.async {
                        print("Server error when adding member to group")
                    }
                }
            }.resume()
        }
    }




// MARK: - GroupDetailView
struct GroupDetailView: View {
    var group: Group
    var friends: [UserProfile]  // Pass friends list from the parent view

    var body: some View {
        List {
            Section(header: Text("Members")) {
                ForEach(group.members, id: \.id) { member in
                    Text(member.username) // This assumes 'username' is a property of 'UserProfile'
                }
            }
            Section {
                Button("Leave Group") {
                    leaveGroup(groupId: group.id)
                }
                .foregroundColor(.red)
            }
            Section(header: Text("Recommendations")) {
                Button("See Recommendations") {
                    seeRecommendations()
                }
            }
        }
        .navigationBarTitle(group.name)
    }

    private func leaveGroup(groupId: String) {
            guard let userId = Auth.auth().currentUser?.uid else {
                print("No authenticated user found")
                return
            }

            let url = URL(string: "http://127.0.0.1:5000/leave-group")! // Replace with your server URL
            var request = URLRequest(url: url)
            request.httpMethod = "POST"
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            
            let leaveGroupData: [String: String] = [
                "group_id": groupId,
                "member_id": userId
            ]
            
            request.httpBody = try? JSONSerialization.data(withJSONObject: leaveGroupData)

            URLSession.shared.dataTask(with: request) { data, response, error in
                if let error = error {
                    DispatchQueue.main.async {
                        print("Error leaving group: \(error.localizedDescription)")
                    }
                    return
                }
                
                guard let httpResponse = response as? HTTPURLResponse,
                      (200...299).contains(httpResponse.statusCode),
                      let data = data,
                      let leaveResponse = try? JSONDecoder().decode(LeaveGroupResponse.self, from: data) else {
                    print("Error or unexpected response from server")
                    return
                }

                if leaveResponse.success {
                    DispatchQueue.main.async {
                        // Handle successful leaving here, such as updating the UI or showing a confirmation message
                        print(leaveResponse.message)
                    }
                } else {
                    DispatchQueue.main.async {
                        // Handle failure here, such as showing an error message
                        print(leaveResponse.message)
                    }
                }
            }.resume()
        }
    

    private func seeRecommendations() {
        // Your implementation of seeing recommendations
    }
}

// MARK: - Data Models
struct Group: Identifiable {
    let id: String
    var name: String
    var admin: String
    var members: [UserProfile]
}


struct GroupsView_Previews: PreviewProvider {
    static var previews: some View {
        GroupsView()
    }
}
// Define the response structure for creating a group
struct CreateGroupResponse: Codable {
    let success: Bool
    let message: String
    let group_id: String
}

struct LeaveGroupResponse: Codable {
    let success: Bool
    let message: String
}
