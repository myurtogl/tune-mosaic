//
//  APIConstants.swift
//  tune-mosaic
//
//  Created by Kaan Aras on 9.12.2023.
//

import Foundation

enum APIConstants{
    static let apiHost = "api.spotify.com"
    static let authHost = "accounts.spotify.com"
    static let clientId = "3abd857f02f24204a008bcde2491f513"
    static let clientSecret = "e98640512a7147afa332591a85536b4c"
    static let redirectUri = "https://example.org/callback"
    static let responseType = "token"
    static let scopes = "user-read-private"
    
    static var authParams = [
        "response_type": responseType,
        "client_id": clientId,
        "redirect_uri": redirectUri,
        "scope": scopes
    ]
}
