//
//  EditProfileView.swift
//  tune-mosaic
//
//  Created by Kaan Aras on 5.12.2023.
//

import SwiftUI

struct EditProfileView: View {
    var user: UserProfile

    @State private var username: String
    @State private var email: String
    @State private var profileImage: Image?
    @State private var showingImagePicker = false
    @State private var inputImage: UIImage?

    init(user: UserProfile) {
        self.user = user
        _username = State(initialValue: user.username)
        _email = State(initialValue: user.email)

        // Attempt to load the profile picture
        if let uiImage = UIImage(named: user.profilePicture) {
            // If the profile picture is a local image
            _profileImage = State(initialValue: Image(uiImage: uiImage))
        } else if let url = URL(string: user.profilePicture), let imageData = try? Data(contentsOf: url), let uiImage = UIImage(data: imageData) {
            // If the profile picture is a URL
            _profileImage = State(initialValue: Image(uiImage: uiImage))
        }
    }

    var body: some View {
        VStack {
            profileImage?
                .resizable()
                .scaledToFit()
                .frame(width: 120, height: 120)
                .clipShape(Circle())
                .overlay(Circle().stroke(Color.white, lineWidth: 4))
                .shadow(radius: 10)
                .padding(.top, 20)
                .onTapGesture {
                    self.showingImagePicker = true
                }

            if profileImage == nil {
                Button(action: { self.showingImagePicker = true }) {
                    Text("Select Profile Picture")
                }
            }

            TextField("Username", text: $username)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()

            TextField("Email", text: $email)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()

            Button("Save Changes") {
                // Implement the save action
            }
            .padding()

            Spacer()
        }
        .navigationBarTitle("Edit Profile", displayMode: .inline)
        .sheet(isPresented: $showingImagePicker, onDismiss: loadImage) {
            ImagePicker(image: self.$inputImage)
        }
    }

    func loadImage() {
        guard let inputImage = inputImage else { return }
        profileImage = Image(uiImage: inputImage)
    }

    struct ImagePicker: UIViewControllerRepresentable {
        @Binding var image: UIImage?

        func makeUIViewController(context: Context) -> UIImagePickerController {
            let picker = UIImagePickerController()
            picker.delegate = context.coordinator
            return picker
        }

        func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {}

        func makeCoordinator() -> Coordinator {
            Coordinator(self)
        }

        class Coordinator: NSObject, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
            let parent: ImagePicker

            init(_ parent: ImagePicker) {
                self.parent = parent
            }

            func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
                if let uiImage = info[.originalImage] as? UIImage {
                    parent.image = uiImage
                }

                picker.dismiss(animated: true)
            }
        }
    }
}

// Preview
struct EditProfileView_Previews: PreviewProvider {
    static var previews: some View {
        EditProfileView(user: UserProfile(id: "1", username: "SampleUser", profilePicture: "defaultProfilePic", email: "sample@email.com"))
    }
}
