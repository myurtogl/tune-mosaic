//
//  UserProfileView.swift
//  tune-mosaic
//
//  Created by Kaan Aras on 13.11.2023.
//

import SwiftUI

struct UserProfileView: View {
    var user: UserProfile

    
    // State variables for navigation
    @State private var showEditProfile = false
    @State private var showChangePassword = false
    @State private var returntoLogin = false
    
    var body: some View {
        VStack {
            Image(user.profilePicture) // Make sure this image is in your Assets.xcassets
                .resizable()
                .scaledToFit()
                .frame(width: 120, height: 120)
                .clipShape(Circle())
                .overlay(Circle().stroke(Color.white, lineWidth: 4))
                .shadow(radius: 10)
                .padding(.top, 20)

            Text(user.username) // Display the username
                .font(.title2)
                .fontWeight(.bold)

            Form {
                Section(header: Text("Personal Information")) {
                    HStack {
                        Text("Username")
                        Spacer()
                        Text(user.username)
                            .foregroundColor(.gray)
                            .lineLimit(1)
                    }
                }
                
                Section(header: Text("Actions")) {
                    Button("Edit Profile"){showEditProfile = true}
                    Button("Change Password"){showChangePassword = true}
                    Button("Log Out"){returntoLogin = true}
                }
            }
            .background(NavigationLink("", destination: EditProfileView(), isActive: $showEditProfile).hidden())
            .background(NavigationLink("", destination: ChangePasswordView(), isActive: $showChangePassword).hidden())
            .background(NavigationLink("", destination: LoginView(), isActive: $returntoLogin).hidden())
        }
        .navigationBarTitle("Profile", displayMode: .large)
                }

    }


struct UserProfileView_Previews: PreviewProvider {
    static var previews: some View {
        UserProfileView(user: UserProfile(id: "1", username: "SampleUser", profilePicture: "e73117c2-0ca1-46ed-9bfd-946766afefa7"))
    }
}



