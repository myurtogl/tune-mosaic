//
//  UserProfileView.swift
//  tune-mosaic
//
//  Created by Kaan Aras on 13.11.2023.
//

import SwiftUI

struct UserProfileView: View {
    var user: UserProfile

    var body: some View {
        VStack {
            Image(user.profilePicture) // Make sure this image is in your Assets.xcassets
                .resizable()
                .scaledToFit()
                .frame(width: 120, height: 120)
                .clipShape(Circle())
                .overlay(Circle().stroke(Color.white, lineWidth: 4))
                .shadow(radius: 10)
                .padding(.top, 20)

            Text(user.username) // Display the username
                .font(.title2)
                .fontWeight(.bold)

            Form {
                Section(header: Text("Personal Information")) {
                    HStack {
                        Text("Username")
                        Spacer()
                        Text(user.username)
                            .foregroundColor(.gray)
                            .lineLimit(1)
                    }
                }
                
                Section(header: Text("Actions")) {
                    Button("Edit Profile", action: editProfile)
                    Button("Change Password", action: changePassword)
                    Button("Log Out", action: logOut)
                }
            }
        }
        .navigationBarTitle("Profile", displayMode: .large)
    }
    
    func editProfile() {
        print("Edit profile tapped")
    }
    
    func changePassword() {
        print("Change password tapped")
    }
    
    func logOut() {
        print("Log out tapped")
    }
}

struct UserProfileView_Previews: PreviewProvider {
    static var previews: some View {
        UserProfileView(user: UserProfile(id: "1", username: "SampleUser", profilePicture: "e73117c2-0ca1-46ed-9bfd-946766afefa7"))
    }
}

