//
//  UserProfileView.swift
//  tune-mosaic
//
//  Created by Kaan Aras on 13.11.2023.
//

import SwiftUI
import FirebaseAuth
import UniformTypeIdentifiers

struct UserProfileView: View {
    @Binding var isLoggedIn: Bool
    var user: UserProfile
    var newPostHandler: () -> Void
    @State private var songInput: String = ""
    
    @State private var newPostText: String = ""
    @State private var isFileSelected: Bool = false
    
    @State private var showEditProfile = false
    @State private var showChangePassword = false
    @State private var showRatedSongs = false
    @State private var showDocumentPicker = false
    @State private var showingLogoutConfirmation = false
    @State private var songInputData = SongInputData()
    @State private var selectedFileURL: URL? = nil


    var body: some View {
        NavigationView {
            VStack {
                Image(user.profilePicture)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 120, height: 120)
                    .clipShape(Circle())
                    .overlay(Circle().stroke(Color.white, lineWidth: 4))
                    .shadow(radius: 10)
                    .padding(.top, 20)
                
                Text(user.username)
                    .font(.title2)
                    .fontWeight(.bold)
                
                Form {
                    Section(header: Text("Create New Post")) {
                        TextEditor(text: $songInput)
                            .frame(minHeight: 100) // Set a minimum height
                            .overlay(
                                RoundedRectangle(cornerRadius: 8)
                                    .stroke(Color.gray, lineWidth: 1)
                            )
                            .padding()
                        
                        Button("Add File") {
                            showDocumentPicker = true
                        }
                        .sheet(isPresented: $showDocumentPicker) {
                            DocumentPicker(
                                isFileSelected: $isFileSelected,
                                selectedFileURL: $selectedFileURL,
                                onFilePicked: processAndUploadFile,
                                allowedContentTypes: [UTType.text, UTType.commaSeparatedText, UTType.json]
                            )
                        }

                        
                        Button("Post") {
                            parseAndPostSong(input: songInput)
                            songInput = "" // Reset the TextEditor
                        }
                        //.disabled(songInputData.songName.isEmpty || songInputData.albumName.isEmpty)


                    }
                    
                    Section(header: Text("Personal Information")) {
                        HStack {
                            Text("Username")
                            Spacer()
                            Text(user.username)
                                .foregroundColor(.gray)
                                .lineLimit(1)
                        }
                    }
                    
                    Section(header: Text("Actions")) {
                        Button("Edit Profile") {
                            showEditProfile = true
                        }
                        .background(NavigationLink("", destination: EditProfileView(user: user), isActive: $showEditProfile).hidden())
                        
                        Button("Change Password") {
                            showChangePassword = true
                        }
                        .background(NavigationLink("", destination: ChangePasswordView(), isActive: $showChangePassword).hidden())
                        
                        Button("Log Out") {
                            showingLogoutConfirmation = true
                        }
                        .alert(isPresented: $showingLogoutConfirmation) {
                            Alert(
                                title: Text("Confirm Logout"),
                                message: Text("Are you sure you want to log out?"),
                                primaryButton: .destructive(Text("Log Out")) {
                                    isLoggedIn = false
                                },
                                secondaryButton: .cancel()
                            )
                        }
                    }
                }
                
                Button("Songs") {
                    showRatedSongs = true
                }
                .background(NavigationLink("", destination: RatedSongsView(), isActive: $showRatedSongs).hidden())
                
                .sheet(isPresented: $showDocumentPicker) {
                    DocumentPicker(
                        isFileSelected: $isFileSelected,
                        selectedFileURL: $selectedFileURL,
                        onFilePicked: { fileURL in
                            // Process the file and upload it
                            processAndUploadFile(fileURL: fileURL)
                        },
                        allowedContentTypes: [UTType.text, UTType.commaSeparatedText, UTType.json]
                    )
                }


            }
            .navigationBarTitle("Profile", displayMode: .large)
        }
        .onChange(of: isLoggedIn) { newValue in
            if !newValue {
                showEditProfile = false
                showChangePassword = false
                showRatedSongs = false
                showDocumentPicker = false
            }
        }
    }
    
    func parseAndPostSong(input: String) {
        // First, print out the raw input to see what is actually being passed in
            print("Raw input:", input)

            // Replace typographic quotes with straight quotes and fix date enclosure
            let processedInput = input
                .replacingOccurrences(of: "“", with: "\"")
                .replacingOccurrences(of: "”", with: "\"")
                .replacingOccurrences(of: "‘", with: "'")
                .replacingOccurrences(of: "’", with: "'")
                .replacingOccurrences(of: "\u{2028}", with: "") // Line Separator
                .replacingOccurrences(of: "\u{2029}", with: "") // Paragraph Separator
                .replacingOccurrences(of: "\u{200B}", with: "") // Zero Width Space
                .replacingOccurrences(of: "\n", with: "") // New Line
                .replacingOccurrences(of: "\r", with: "") // Carriage Return
                .trimmingCharacters(in: .whitespacesAndNewlines) // Trim whitespaces and newlines

            // Then, print out the processed input to see if the replacements were successful
            print("Processed input:", processedInput)

        guard let inputData = processedInput.data(using: .utf8),
                  let jsonArray = try? JSONSerialization.jsonObject(with: inputData, options: []),
                  let songArray = jsonArray as? [[String: Any]] else {
                print("Invalid JSON format after processing.")
                return
            }

            for songDict in songArray {
                if let songData = parseSongData(from: songDict) {
                    addSong(songData: songData)
                } else {
                    print("Missing or invalid song data fields in one of the entries")
                }
            }
    }
    
    func parseSongData(from dict: [String: Any]) -> SongInputData? {
        guard let songName = dict["songName"] as? String,
              let albumName = dict["albumName"] as? String,
              let performer = dict["performer"] as? String,
              let genre = dict["genre"] as? String,
              let mood = dict["mood"] as? String,
              let rating = dict["rating"] as? Int,
              let dateOfRatingString = dict["dateOfRating"] as? String else {
            return nil
        }

        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd.MM.yy"
        let dateOfRating = dateFormatter.date(from: dateOfRatingString)

        return SongInputData(
            songName: songName,
            albumName: albumName,
            performer: performer,
            genre: genre,
            mood: mood,
            rating: rating,
            dateOfRating: dateOfRating
        )
    }


    func processAndUploadFile(fileURL: URL) {
        do {
            let fileContents = try String(contentsOf: fileURL, encoding: .utf8)
            parseAndPostSong(input: fileContents)
        } catch {
            print("Error reading file: \(error)")
        }
    }




    func addSong(songData: SongInputData) {
        guard let user = Auth.auth().currentUser else {
            print("No authenticated user found")
            // Consider adding user feedback here
            return
        }
        
        let userId = user.uid
        let formatter = ISO8601DateFormatter()

        var songDataDict: [String: Any] = [
                "songName": songData.songName,
                "albumName": songData.albumName,
                "performer": songData.performer,
                "genre": songData.genre,
                "mood": songData.mood,
                "rating": songData.rating
        ]
        
        // Handle optional dateOfRating
        if let dateOfRating = songData.dateOfRating {
            songDataDict["dateOfRating"] = formatter.string(from: dateOfRating)
        } else {
            songDataDict["dateOfRating"] = nil
        }

        let postData: [String: Any] = [
            "user_id": userId,
            "song_data": songDataDict
        ]

        guard let jsonData = try? JSONSerialization.data(withJSONObject: postData, options: []) else {
            print("Error creating JSON")
            // Consider adding user feedback here
            return
        }

        guard let url = URL(string: "http://127.0.0.1:5000/add-song") else { return }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = jsonData
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Error: \(error)")
                // Consider adding user feedback here
                return
            }
            if let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 {
                print("Song added successfully")
                // Consider adding user feedback here
            } else {
                print("Error adding song: \(String(describing: response))")
                // Consider adding user feedback here
            }
        }.resume()
    }

}

struct UserProfileView_Previews: PreviewProvider {
    static var previews: some View {
        UserProfileView(
            isLoggedIn: .constant(true),
            user: UserProfile(
                id: "c6MdQAEMxuSPC57mbZxA9JAkidw2",
                username: "umutdeser",
                email: "umut@deser.com", // Replace with an appropriate value
                name: "Umut",            // Replace with an appropriate value
                surname: "Deser",        // Replace with an appropriate value
                profilePicture: "e73117c2-0ca1-46ed-9bfd-946766afefa7" // Include if you have this field in your struct
            ),
            newPostHandler: {}
        )
    }
}


struct SongInputData {
    var songName: String = ""
    var albumName: String = ""
    var performer: String = ""
    var genre: String = ""
    var mood: String = ""
    var rating: Int = 0
    var dateOfRating: Date? = nil
}




// Helper function to append strings to NSMutableData
private extension NSMutableData {
    func appendString(_ string: String) {
        if let data = string.data(using: .utf8) {
            self.append(data)
        }
    }
}



// You'll need to adjust the DocumentPicker and the EditProfileView, ChangePasswordView, and RatedSongsView
// to your actual implementations. The code above assumes these are already defined elsewhere in your project.



struct DocumentPicker: UIViewControllerRepresentable {
    @Binding var isFileSelected: Bool
    @Binding var selectedFileURL: URL?
    var onFilePicked: (URL) -> Void
    var allowedContentTypes: [UTType]

    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: allowedContentTypes, asCopy: true)
        picker.delegate = context.coordinator
        return picker
    }

    func updateUIViewController(_ uiViewController: UIDocumentPickerViewController, context: Context) {
        // No need to update the UIViewController in this case
    }

    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }

    class Coordinator: NSObject, UIDocumentPickerDelegate {
        var parent: DocumentPicker

        init(_ parent: DocumentPicker) {
            self.parent = parent
        }

        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            guard let pickedURL = urls.first else { return }
            parent.isFileSelected = true
            parent.selectedFileURL = pickedURL
            parent.onFilePicked(pickedURL) // Call the closure with the selected file URL
        }

        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
            parent.isFileSelected = false
        }
    }
}

