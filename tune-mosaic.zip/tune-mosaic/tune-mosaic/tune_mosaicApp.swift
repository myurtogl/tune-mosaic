//
//  tune_mosaicApp.swift
//  tune-mosaic
//
//  Created by Kaan Aras on 2.11.2023.
//

import SwiftUI

@main
struct tune_mosaicApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
