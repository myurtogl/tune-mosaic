//
//  tune_mosaicApp.swift
//  tune-mosaic
//
//  Created by Kaan Aras on 2.11.2023.
//

import SwiftUI

@main
struct tune_mosaicApp: App {
    var body: some Scene {
        WindowGroup {
            //ContentView()
            MainFeedView(currentUserProfile: UserProfile(id: "2", username: "user2", profilePicture: "0858e72e-bc03-43a7-9361-390354f7186d"))
        }
    }
}
