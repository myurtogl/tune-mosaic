//
//  tune_mosaicApp.swift
//  tune-mosaic
//
//  Created by Kaan Aras on 2.11.2023.
//

import SwiftUI
import FirebaseCore

class AppDelegate: NSObject, UIApplicationDelegate {
  func application(_ application: UIApplication,
                   didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
    FirebaseApp.configure()
    return true
  }
}



@main
struct tune_mosaicApp: App {
    
    @UIApplicationDelegateAdaptor(AppDelegate.self) var delegate
    
    var body: some Scene {
        WindowGroup {
            //RootView()
            ContentView()
            /*
            // Assuming you have a sample user to pass as an argument
                        // Replace with actual logic to determine logged in status and user data
                        let sampleUser = UserProfile(id: "1", username: "SampleUser", profilePicture: "e73117c2-0ca1-46ed-9bfd-946766afefa7")
                        let isLoggedIn = true // Replace with actual logic for logged in status

                        UserProfileView(isLoggedIn: .constant(isLoggedIn), user: sampleUser, newPostHandler: {
                            // Dummy handler function
                            // Replace with actual post handling logic
                        })*/
        }
    }
}
