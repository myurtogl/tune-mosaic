//
//  MusicPost.swift
//  tune-mosaic
//
//  Created by Kaan Aras on 13.11.2023.
//

import Foundation

// MusicPost.swift
struct MusicPost: Identifiable {
    var id: String
    var user: UserProfile
    var songName: String
    var artistName: String
    var rating: Int
    // Add more properties as needed
}

// UserProfile.swift
struct UserProfile: Identifiable {
    let id: String
    var username: String
    var email: String
    var name: String
    var surname: String
    let profilePicture: String
    
}

// Equatable conformance for UserProfile
extension UserProfile: Equatable {
    static func ==(lhs: UserProfile, rhs: UserProfile) -> Bool {
        return lhs.id == rhs.id
    }
}

struct Friend: Identifiable {
    let id: String
    let username: String
    var activityShare: Bool 
}

