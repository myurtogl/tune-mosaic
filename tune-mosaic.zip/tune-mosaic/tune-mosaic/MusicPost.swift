//
//  MusicPost.swift
//  tune-mosaic
//
//  Created by Kaan Aras on 13.11.2023.
//

import Foundation

// MusicPost.swift
struct MusicPost: Identifiable {
    let id: String
    let user: UserProfile
    let songName: String
    let artistName: String
    let likes: Int
    // Add more properties as needed
}

// UserProfile.swift
struct UserProfile: Identifiable {
    let id: String
    let username: String
    let profilePicture: String // Image name or URL
}
