//
//  MusicPost.swift
//  tune-mosaic
//
//  Created by Kaan Aras on 13.11.2023.
//

import Foundation

// MusicPost.swift
struct MusicPost: Identifiable {
    var id: String
    var user: UserProfile
    var songName: String
    var artistName: String
    var likes: Int
    // Add more properties as needed
}

// UserProfile.swift
struct UserProfile: Identifiable {
    var id: String
    var username: String
    var profilePicture: String // Image name or URL
}
