//
//  RatedSongsView.swift
//  tune-mosaic
//
//  Created by Kaan Aras on 9.12.2023.
//

import SwiftUI
import FirebaseAuth
import FirebaseDatabase

struct RatedSongsView: View {
    @State private var Songs: [Song] = []
    @State private var showingAlbumsView = false
    @State private var showingPerformersView = false
    @State private var ratedSongs: [Song] = []
    @State private var showOnlyUnrated: Bool = false // State for toggle

    var body: some View {
        NavigationView {
            VStack {
                Toggle(isOn: $showOnlyUnrated) {
                    Text(showOnlyUnrated ? "Showing Only Rated Songs" : "Showing All Songs")
                }
                .padding()
                
                List {
                    ForEach(filteredSongs, id: \.id) { song in
                        HStack {
                            VStack(alignment: .leading) {
                                Text(song.name)
                                    .font(.headline)
                                Text(song.artist)
                                    .font(.subheadline)
                                
                                HStack {
                                ForEach(1...5, id: \.self) { rating in
                                    Image(systemName: song.rating >= rating ? "star.fill" : "star")
                                        .foregroundColor(song.rating >= rating ? .yellow : .gray)
                                        .onTapGesture {
                                            updateRating(for: song.id, with: rating)
                                        }
                                    }
                                }
                            }
                            .padding()
                            
                            Spacer()
                            
                            Button(action: {
                                deleteSong(songId: song.id)
                            }) {
                                Image(systemName: "trash")
                                    .foregroundColor(.red)
                            }
                        }
                    }
                    .onDelete(perform: removeSongs)
                }
            }
            .navigationBarTitle("Songs")
            .onAppear(perform: loadRatedSongs)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Menu {
                        Button("Manage Albums", action: { showingAlbumsView = true })
                        Button("Manage Artists", action: { showingPerformersView = true })
                    } label: {
                        Label("Manage", systemImage: "slider.horizontal.3")
                    }
                }
            }
            .sheet(isPresented: $showingAlbumsView) {
                AlbumsView()
            }
            .sheet(isPresented: $showingPerformersView) {
                PerformersView()
            }
            .onAppear(perform: loadRatedSongs)
        }
    }
    
    // Computed property to filter songs based on the toggle
    private var filteredSongs: [Song] {
        showOnlyUnrated ? Songs.filter { $0.rating > 0 } : Songs
    }

    private func loadRatedSongs() {
        guard let user = Auth.auth().currentUser else {
            print("No authenticated user found")
            return
        }

        let userId = user.uid
        let ref = Database.database().reference(withPath: "users/\(userId)/songs")

        ref.observeSingleEvent(of: .value) { snapshot in
            var newSongs: [Song] = []

            for child in snapshot.children {
                if let snapshot = child as? DataSnapshot,
                   let songDict = snapshot.value as? [String: AnyObject],
                   let name = songDict["Name"] as? String,
                   let artist = songDict["Artist"] as? String,
                   let album = songDict["Album"] as? String,
                   let releaseDate = songDict["Release Date"] as? String,
                   let durationMs = songDict["Duration (ms)"] as? Int,
                   let genre = songDict["Genre"] as? String,
                   let danceability = songDict["Danceability"] as? Double,
                   let energy = songDict["Energy"] as? Double,
                   let valence = songDict["Valence"] as? Double,
                   let rating = songDict["rating"] as? Int,
                   let dateOfRating = songDict["dateOfRating"] as? String,
                   rating >= 0 { // Only add songs with a rating greater than 0
                    
                    let previewURL = songDict["Preview URL"] as? String

                    let song = Song(
                        id: snapshot.key,
                        name: name,
                        artist: artist,
                        album: album,
                        releaseDate: releaseDate,
                        durationMs: durationMs,
                        previewURL: previewURL,
                        genre: genre,
                        danceability: danceability,
                        energy: energy,
                        valence: valence,
                        rating: rating,
                        dateOfRating: dateOfRating
                    )
                    newSongs.append(song)
                }
            }

            DispatchQueue.main.async {
                self.Songs = newSongs.sorted { $0.name < $1.name } // Sort songs by name
            }
        }
    }


    private func deleteSong(songId: String) {
        guard let user = Auth.auth().currentUser else {
            print("No authenticated user found")
            return
        }

        let userId = user.uid
        let ref = Database.database().reference(withPath: "users/\(userId)/songs/\(songId)")

        ref.removeValue { error, _ in
            if let error = error {
                print("Error deleting song: \(error.localizedDescription)")
                return
            }
            
            // Remove the song from the local array
            if let index = self.Songs.firstIndex(where: { $0.id == songId }) {
                DispatchQueue.main.async {
                    self.Songs.remove(at: index)
                }
            }
        }
    }

    private func updateRating(for songId: String, with rating: Int) {
        guard let user = Auth.auth().currentUser else {
            print("No authenticated user found")
            return
        }

        let userId = user.uid
        let ref = Database.database().reference(withPath: "users/\(userId)/songs/\(songId)")
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd.MM.yy"
        let dateOfRatingString = dateFormatter.string(from: Date())

        ref.updateChildValues(["rating": rating, "dateOfRating": dateOfRatingString]) { error, _ in
            if let error = error {
                print("Error updating rating: \(error.localizedDescription)")
                return
            }
            
            // Update the local array
            if let index = self.Songs.firstIndex(where: { $0.id == songId }) {
                DispatchQueue.main.async {
                    self.Songs[index].rating = rating
                    self.Songs[index].dateOfRating = dateOfRatingString
                }
            }
        }
    }

    private func removeSongs(at offsets: IndexSet) {
        offsets.forEach { index in
            let songId = Songs[index].id
            deleteSong(songId: songId)
        }
        Songs.remove(atOffsets: offsets)
    }
}

struct Song: Identifiable, Codable {
    let id: String
    var name: String
    var artist: String
    var album: String
    var releaseDate: String
    var durationMs: Int
    var previewURL: String?
    var genre: String
    var danceability: Double
    var energy: Double
    var valence: Double
    var rating: Int
    var dateOfRating: String
}

struct RatedSongsView_Previews: PreviewProvider {
    static var previews: some View {
        RatedSongsView()
    }
}
