import SwiftUI
import FirebaseAuth
import FirebaseDatabase


struct FriendshipView: View {
    var userProfile: UserProfile
    @State private var searchText = ""
    @State private var users: [UserProfile] = []
    @State private var following: [String] = []
    @State private var friends: [Friend] = []

    var body: some View {
        NavigationView {
            List {
                Section(header: Text("Users")) {
                    ForEach(users.filter { $0.id != userProfile.id }) { user in
                        UserRow(user: user, isFollowing: following.contains(user.id)) {
                            if following.contains(user.id) {
                                followOrUnfollowUser(user: user, shouldFollow: false)
                            } else {
                                followOrUnfollowUser(user: user, shouldFollow: true)
                            }
                        }
                    }
                }
                
                Section(header: Text("Privacy Settings")) {
                    ForEach($friends) { $friend in
                        HStack {
                            Text(friend.username)
                            Spacer()
                            Toggle("Activity Share", isOn: $friend.activityShare)
                                .onChange(of: friend.activityShare) { newValue in
                                    updateActivityShare(for: friend.id, to: newValue)
                                }
                        }
                    }
                }

            }
            .searchable(text: $searchText, prompt: "Search for users")
            .navigationBarTitle("Users")
            .onAppear {
                loadFollowingStatus()
                loadUsers()
                loadFriends()
            }
        }
    }
    
    func loadFollowingStatus() {
        guard let currentUserId = Auth.auth().currentUser?.uid else { return }

        let followingRef = Database.database().reference().child("users").child(currentUserId).child("following")
        followingRef.observeSingleEvent(of: .value) { snapshot in
            var currentUserFollowing = [String]()
            if let followingArray = snapshot.value as? [String] {
                currentUserFollowing = followingArray
            } else if let followingDict = snapshot.value as? [String: AnyObject] {
                currentUserFollowing = Array(followingDict.keys)
            }

            DispatchQueue.main.async {
                self.following = currentUserFollowing
            }
        }
    }



    func loadUsers() {
        guard let currentUserId = Auth.auth().currentUser?.uid else {
            print("No authenticated user found")
            return
        }

        print("Current authenticated user's id: \(currentUserId)")

        let usersRef = Database.database().reference().child("users")
        usersRef.observeSingleEvent(of: .value) { snapshot in
            var newUsers: [UserProfile] = []
            
            guard let userSnapshots = snapshot.children.allObjects as? [DataSnapshot] else {
                print("Snapshot casting error or no users.")
                return
            }
            
            for userSnapshot in userSnapshots {
                let userId = userSnapshot.key
                print("Loaded user id: \(userId)")
                
                if userId == currentUserId {
                    print("Current user found in snapshot, skipping...")
                    continue
                }
                
                if let userDict = userSnapshot.value as? [String: AnyObject] {
                    let username = userDict["username"] as? String ?? "Unknown"
                    let email = userDict["email"] as? String ?? "No email"
                    let name = userDict["name"] as? String ?? "No name"
                    let surname = userDict["surname"] as? String ?? "No surname"
                    let profilePicture = userDict["profilePicture"] as? String ?? "defaultProfilePicture"
                    
                    let newUser = UserProfile(id: userId, username: username, email: email, name: name, surname: surname, profilePicture: profilePicture)
                    newUsers.append(newUser)
                } else {
                    print("Error: User data for user \(userId) is incomplete.")
                }
            }
            
            DispatchQueue.main.async {
                self.users = newUsers
                print("Users loaded: \(self.users.map { $0.username })")
            }
        }
    }



    
    func loadFriends() {
        guard let currentUserId = Auth.auth().currentUser?.uid else { return }

        let friendsRef = Database.database().reference().child("users").child(currentUserId).child("friends")
        friendsRef.observeSingleEvent(of: .value) { snapshot in
            var loadedFriends: [Friend] = []
            let friendsDict = snapshot.value as? [String: [String: Bool]] ?? [:]

            let group = DispatchGroup()
            for (friendId, details) in friendsDict {
                group.enter()
                let userRef = Database.database().reference().child("users").child(friendId)
                userRef.observeSingleEvent(of: .value, with: { userSnapshot in
                    if let userDict = userSnapshot.value as? [String: Any],
                       let username = userDict["username"] as? String,
                       let activityShare = details["activityShare"] {
                        let friend = Friend(id: friendId, username: username, activityShare: activityShare)
                        loadedFriends.append(friend)
                    }
                    group.leave()
                })
            }

            group.notify(queue: .main) {
                self.friends = loadedFriends
            }
        }
    }



    func updateActivityShare(for friendId: String, to newValue: Bool) {
        guard let currentUserId = Auth.auth().currentUser?.uid else { return }
        
        let url = URL(string: "http://127.0.0.1:5000/update-friend-activity-share")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.httpBody = try? JSONSerialization.data(withJSONObject: [
            "owner_id": currentUserId,
            "friend_id": friendId,
            "activityShare": newValue
        ])
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                DispatchQueue.main.async {
                    // Handle the error by updating some state or showing an alert to the user
                }
                print("Error updating activity share: \(error.localizedDescription)")
                return
            }
            
            if let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 {
                DispatchQueue.main.async {
                    if let index = self.friends.firstIndex(where: { $0.id == friendId }) {
                        var friend = self.friends[index]
                        friend.activityShare = newValue
                        self.friends[index] = friend  // Safely updating the array
                    }
                }
            } else {
                DispatchQueue.main.async {
                    // Handle unexpected response by updating some state or showing an alert to the user
                }
                print("Unexpected response from server when updating activity share")
            }
        }.resume()
    }




    func followOrUnfollowUser(user: UserProfile, shouldFollow: Bool) {
        guard let currentUserId = Auth.auth().currentUser?.uid else { return }
        
        // Define the URL for the backend endpoint based on the action
        let endpoint = shouldFollow ? "follow-user" : "unfollow-user"
        guard let url = URL(string: "http://127.0.0.1:5000/\(endpoint)") else { return }
        
        // Create the JSON data to send to the backend
        let requestData: [String: String] = [
            shouldFollow ? "follower_id" : "active_user_id": currentUserId,
            shouldFollow ? "followed_id" : "unfollow_user_id": user.id
        ]
        guard let jsonData = try? JSONSerialization.data(withJSONObject: requestData) else { return }
        
        // Create the request
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.httpBody = jsonData
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        // Start the data task
        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Error while trying to \(shouldFollow ? "follow" : "unfollow") user: \(error.localizedDescription)")
                return
            }
            
            if let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 {
                DispatchQueue.main.async {
                    if shouldFollow {
                        self.following.append(user.id)
                    } else {
                        self.following.removeAll(where: { $0 == user.id })
                    }
                }
            } else {
                print("Unexpected response from server")
            }
        }.resume()
    }

}

struct UserRow: View {
    let user: UserProfile
    let isFollowing: Bool
    let followAction: () -> Void

    var body: some View {
        HStack {
            // This should be replaced with actual image fetching logic
            Image(systemName: "person.fill")
                .resizable()
                .frame(width: 40, height: 40)
                .clipShape(Circle())
            Text(user.username)
            Spacer()
            Button(action: followAction) {
                Text(isFollowing ? "Unfollow" : "Follow")
            }
        }
    }
}


struct FriendshipView_Previews: PreviewProvider {
    static var previews: some View {
        FriendshipView(userProfile: UserProfile(
            id: "dummyID",
            username: "DummyUser",
            email: "dummy@example.com",
            name: "Dummy",
            surname: "User",
            profilePicture: "defaultProfilePicture" // Replace with actual profile picture
        ))
    }
}
