//
//  ChangePasswordView.swift
//  tune-mosaic
//
//  Created by Kaan Aras on 5.12.2023.
//

import SwiftUI

struct ChangePasswordView: View {
    @State private var currentPassword: String = ""
    @State private var newPassword: String = ""
    @State private var confirmPassword: String = ""
    @State private var errorMessage: String? = nil
    
    
    var body: some View {
        VStack {
            SecureField("Current Password", text: $currentPassword)
                .padding()
                .background(Color.gray.opacity(0.2))
                .cornerRadius(5.0)
                .padding(.bottom, 20)
            
            SecureField("New Password", text: $newPassword)
                .padding()
                .background(Color.gray.opacity(0.2))
                .cornerRadius(5.0)
                .padding(.bottom, 20)
            
            SecureField("Confirm New Password", text: $confirmPassword)
                .padding()
                .background(Color.gray.opacity(0.2))
                .cornerRadius(5.0)
                .padding(.bottom, 20)
            
            if let errorMessage = errorMessage {
                    Text(errorMessage)
                        .foregroundColor(.red)
                }
            
            Button(action: changePassword) {
                Text("Change Password")
                    .foregroundColor(.white)
                    .frame(width: 220, height: 60)
                    .background(Color.blue)
                    .cornerRadius(15.0)
            }
        }
        .padding()
    }
    
    private func changePassword() {
        // Reset error message
        errorMessage = nil
        
        // Validate that new password and confirm password match
        guard newPassword == confirmPassword else {
            errorMessage = "New Password and Confirm New Password do not match."
            return
        }
        
        // Continue with password change logic
        // Send new password to your server here
        
        print("Password change requested")
    }
    
    struct ChangePasswordView_Previews: PreviewProvider {
        static var previews: some View {
            ChangePasswordView()
        }
    }
}
