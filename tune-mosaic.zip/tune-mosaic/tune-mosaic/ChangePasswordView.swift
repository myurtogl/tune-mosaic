//
//  ChangePasswordView.swift
//  tune-mosaic
//
//  Created by Kaan Aras on 5.12.2023.
//

import SwiftUI

struct ChangePasswordView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    ChangePasswordView()
}
