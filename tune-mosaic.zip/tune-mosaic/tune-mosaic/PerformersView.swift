//
//  PerformersView.swift
//  tune-mosaic
//
//  Created by Kaan Aras on 11.12.2023.
//

import SwiftUI
import FirebaseAuth
import FirebaseDatabase

struct PerformersView: View {
    @State private var performers: [String] = []

    var body: some View {
        NavigationView {
            List {
                ForEach(performers, id: \.self) { performer in
                    Text(performer)
                        .swipeActions {
                            Button(role: .destructive) {
                                deletePerformer(performer)
                            } label: {
                                Label("Delete", systemImage: "trash")
                            }
                        }
                }
            }
            .navigationTitle("Artists")
            .onAppear(perform: loadPerformers)
        }
    }

    private func loadPerformers() {
        // Updated to match new data structure
        guard let user = Auth.auth().currentUser else {
            print("No authenticated user found")
            return
        }

        let userId = user.uid
        let ref = Database.database().reference(withPath: "users/\(userId)/songs")

        ref.observeSingleEvent(of: .value) { snapshot in
            var newPerformers = Set<String>()
            
            for child in snapshot.children {
                if let snapshot = child as? DataSnapshot,
                   let songDict = snapshot.value as? [String: AnyObject],
                   let artist = songDict["Artist"] as? String {
                    newPerformers.insert(artist)
                }
            }
            
            DispatchQueue.main.async {
                self.performers = Array(newPerformers)
            }
        }
    }

    private func deletePerformer(_ performer: String) {
        // Updated to match new data structure
        guard let user = Auth.auth().currentUser else {
            print("No authenticated user found")
            return
        }

        let userId = user.uid
        let ref = Database.database().reference(withPath: "users/\(userId)/songs")

        ref.observeSingleEvent(of: .value) { snapshot in
            let group = DispatchGroup()
            
            for child in snapshot.children {
                group.enter()
                if let snapshot = child as? DataSnapshot,
                   let songDict = snapshot.value as? [String: AnyObject],
                   let artistName = songDict["Artist"] as? String,
                   artistName == performer {
                    ref.child(snapshot.key).removeValue { error, _ in
                        group.leave()
                        if let error = error {
                            print("Error deleting song: \(error.localizedDescription)")
                        }
                    }
                } else {
                    group.leave()
                }
            }
            
            group.notify(queue: .main) {
                self.loadPerformers() // Reload performers after deletion is complete
            }
        }
    }
}
