//
//  ViewController.swift
//  tune-mosaic
//
//  Created by Kaan Aras on 9.12.2023.
//

import Foundation
import UIKit
import WebKit
import SwiftUI

class ViewController: UIViewController {
    
    let authorizationManager = AuthorizationManager()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let token = UserDefaults.standard.value(forKey: "Authorization") {
            NavigationLink(destination: LoginView(isLoggedIn: .constant(true))){
                EmptyView()
            }
            .hidden() // Hide the NavigationLink
        } else {
            getAccessTokenFromWebView()
        }
    }
    
    
    
    func getAccessTokenFromWebView(){
        guard let urlRequest = APIService.shared.getAccessTokenURL() else {return}
        let webview = WKWebView()
        
        webview.load(urlRequest)
        webview.navigationDelegate = self
        view = webview
    }
}

extension ViewController: WKNavigationDelegate {
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        guard let urlString = webView.url?.absoluteString else {return}
        print(urlString)
        
        var tokenString = ""
        // Check if the URL contains the callback URL and code parameter
        if urlString.contains("#acess_token="){
            let range = urlString.range(of: "#access_token=")
            guard let index = range?.upperBound else {return}
            
            tokenString = String(urlString[index...])
            // Use the code to get the access token here, then:
            
            // Notify the AuthorizationManager about successful authentication
            authorizationManager.authenticationDidSucceed = true
            
            // Dismiss the web view controller
            dismiss(animated: true)
        }
        
        if !tokenString.isEmpty {
            let range = tokenString.range(of: "&token_type=Bearer")
            guard let index = range?.lowerBound else { return }
            
            tokenString = String(tokenString[..<index])
            UserDefaults.standard.setValue(tokenString, forKey: "Authorization")
            authorizationManager.authenticationDidSucceed = true
        }
    }
}
