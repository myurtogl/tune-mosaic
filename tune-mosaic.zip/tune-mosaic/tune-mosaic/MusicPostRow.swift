//
//  MusicPostRow.swift
//  tune-mosaic
//
//  Created by Kaan Aras on 13.11.2023.
//

import SwiftUI

struct MusicPostRow: View {
    let post: MusicPost

    var body: some View {
        HStack(alignment: .top) {
            // Profile image of the post creator
            Image(post.user.profilePicture) // Ensure this image exists in your Assets.xcassets
                .resizable()
                .aspectRatio(contentMode: .fill)
                .frame(width: 50, height: 50)
                .clipShape(Circle())
            
            VStack(alignment: .leading) {
                // Song name and artist name
                Text(post.songName).font(.headline)
                Text(post.artistName).font(.subheadline)
                
                // Display number of likes
                HStack {
                    Image(systemName: "heart") // You can use your own like icon image
                        .resizable()
                        .frame(width: 16, height: 16)
                        .foregroundColor(.red)
                    Text("\(post.likes) Likes")
                }
            }
            
            Spacer()
        }
        .padding()
    }
}

struct MusicPostRow_Previews: PreviewProvider {
    static var previews: some View {
        // Create a dummy music post for the preview
        MusicPostRow(post: MusicPost(
            id: "1",
            user: UserProfile(id: "user1", username: "user1", profilePicture: "profilePic1"),
            songName: "Sample Song",
            artistName: "Sample Artist",
            likes: 123
        ))
    }
}
