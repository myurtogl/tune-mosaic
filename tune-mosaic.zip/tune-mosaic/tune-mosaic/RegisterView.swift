//
//  RegisterView.swift
//  tune-mosaic
//
//  Created by Kaan Aras on 2.11.2023.
//

import SwiftUI

struct RegisterView: View {
    @State private var name: String = ""
    @State private var surname: String = ""
    @State private var username: String = ""
    @State private var email: String = ""
    @State private var phoneNumber: String = ""
    @State private var password: String = ""
    @State private var passwordConfirmation: String = ""
    @State private var isPasswordVisible: Bool = false
    @State private var isPasswordConfirmationVisible: Bool = false

    var body: some View {
        ZStack {
            Color.spotifyGreen
                .edgesIgnoringSafeArea(.all)
            
            VStack(spacing: 20) {
                TextField("Name", text: $name)
                    .autocapitalization(.words)
                    .padding()
                    .background(Color.white.opacity(0.1))
                    .cornerRadius(8)
                    .foregroundColor(.white)
                
                TextField("Surname", text: $surname)
                    .autocapitalization(.words)
                    .padding()
                    .background(Color.white.opacity(0.1))
                    .cornerRadius(8)
                    .foregroundColor(.white)
                
                TextField("Username", text: $username)
                    .autocapitalization(.none)
                    .padding()
                    .background(Color.white.opacity(0.1))
                    .cornerRadius(8)
                    .foregroundColor(.white)
                
                TextField("Email", text: $email)
                    .autocapitalization(.none)
                    .padding()
                    .background(Color.white.opacity(0.1))
                    .cornerRadius(8)
                    .foregroundColor(.white)
                
                TextField("Phone Number", text: $phoneNumber)
                    .keyboardType(.numberPad)
                    .padding()
                    .background(Color.white.opacity(0.1))
                    .cornerRadius(8)
                    .foregroundColor(.white)
                
                HStack {
                    if isPasswordVisible {
                        TextField("Password", text: $password)
                    } else {
                        SecureField("Password", text: $password)
                    }
                    Button(action: {
                        isPasswordVisible.toggle()
                    }) {
                        Image(systemName: isPasswordVisible ? "eye.slash.fill" : "eye.fill")
                            .foregroundColor(.white)
                    }
                }
                .padding()
                .background(Color.white.opacity(0.1))
                .cornerRadius(8)
                
                HStack {
                    if isPasswordConfirmationVisible {
                        TextField("Confirm Password", text: $passwordConfirmation)
                    } else {
                        SecureField("Confirm Password", text: $passwordConfirmation)
                    }
                    Button(action: {
                        isPasswordConfirmationVisible.toggle()
                    }) {
                        Image(systemName: isPasswordConfirmationVisible ? "eye.slash.fill" : "eye.fill")
                            .foregroundColor(.white)
                    }
                }
                .padding()
                .background(Color.white.opacity(0.1))
                .cornerRadius(8)
                
                Button(action: {
                    // Handle registration action here
                    register(name: name, surname: surname, username: username, email: email, phoneNumber: phoneNumber, password: password)
                    print("Registering...")
                }) {
                    Text("Register")
                        .padding()
                        .background(Color.black)
                        .foregroundColor(Color.spotifyGreen)
                        .cornerRadius(8)
                }
            }
            .padding(.horizontal, 40)
        }
    }
}

#Preview {
    RegisterView()
}

func register(name: String, surname: String, username: String, email: String, phoneNumber: String, password: String) {
    guard let url = URL(string: "http://127.0.0.1:5000/register") else { return }
    
    let user_data: [String: Any] = [
        "name": name,
        "surname": surname,
        "username": username,
        "email": email,  
        "phone_number": phoneNumber
    ]

    
    let parameters: [String: Any] = [
        "email": email,
        "password": password,
        "user_data": user_data
    ]

    let data = try? JSONSerialization.data(withJSONObject: parameters)
    
    var request = URLRequest(url: url)
    request.httpMethod = "POST"
    request.httpBody = data
    request.addValue("application/json", forHTTPHeaderField: "Content-Type")
    
    URLSession.shared.dataTask(with: request) { data, response, error in
        if let error = error {
            // Handle error here
            print("Error: \(error)")
            return
        }
        
        // Handle response here
        if let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 {
            // Successful registration, handle accordingly
        } else {
            // Handle failure
        }
    }.resume()
}
