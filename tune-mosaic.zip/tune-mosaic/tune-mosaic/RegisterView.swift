//
//  RegisterView.swift
//  tune-mosaic
//
//  Created by Kaan Aras on 2.11.2023.
//

import SwiftUI
import WebKit


struct RegisterView: View {
    @State private var name: String = ""
    @State private var surname: String = ""
    @State private var username: String = ""
    @State private var email: String = ""
    @State private var phoneNumber: String = ""
    @State private var password: String = ""
    @State private var passwordConfirmation: String = ""
    @State private var isPasswordVisible: Bool = false
    @State private var isPasswordConfirmationVisible: Bool = false
    // Add the authorization manager
    @Binding var isLoggedIn: Bool
    // State to control navigation
    @State private var shouldNavigateToLogin = false
    // Add this to observe the auth state
    @ObservedObject var authManager = AuthorizationManager()
    
    var body: some View {
        ZStack {
            Color.spotifyGreen
                .edgesIgnoringSafeArea(.all)
            
            VStack(spacing: 20) {
                TextField("Name", text: $name)
                    .autocapitalization(.words)
                    .padding()
                    .background(Color.white.opacity(0.1))
                    .cornerRadius(8)
                    .foregroundColor(.white)
                
                TextField("Surname", text: $surname)
                    .autocapitalization(.words)
                    .padding()
                    .background(Color.white.opacity(0.1))
                    .cornerRadius(8)
                    .foregroundColor(.white)
                
                TextField("Username", text: $username)
                    .autocapitalization(.none)
                    .padding()
                    .background(Color.white.opacity(0.1))
                    .cornerRadius(8)
                    .foregroundColor(.white)
                
                TextField("Email", text: $email)
                    .autocapitalization(.none)
                    .padding()
                    .background(Color.white.opacity(0.1))
                    .cornerRadius(8)
                    .foregroundColor(.white)
                
                TextField("Phone Number", text: $phoneNumber)
                    .keyboardType(.numberPad)
                    .padding()
                    .background(Color.white.opacity(0.1))
                    .cornerRadius(8)
                    .foregroundColor(.white)
                
                HStack {
                    if isPasswordVisible {
                        TextField("Password", text: $password)
                    } else {
                        SecureField("Password", text: $password)
                    }
                    Button(action: {
                        isPasswordVisible.toggle()
                    }) {
                        Image(systemName: isPasswordVisible ? "eye.slash.fill" : "eye.fill")
                            .foregroundColor(.white)
                    }
                }
                .padding()
                .background(Color.white.opacity(0.1))
                .cornerRadius(8)
                
                HStack {
                    if isPasswordConfirmationVisible {
                        TextField("Confirm Password", text: $passwordConfirmation)
                    } else {
                        SecureField("Confirm Password", text: $passwordConfirmation)
                    }
                    Button(action: {
                        isPasswordConfirmationVisible.toggle()
                    }) {
                        Image(systemName: isPasswordConfirmationVisible ? "eye.slash.fill" : "eye.fill")
                            .foregroundColor(.white)
                    }
                }
                .padding()
                .background(Color.white.opacity(0.1))
                .cornerRadius(8)
                
                Button(action: {
                    // Handle registration action here
                    register(authManager: self.authManager, name: name, surname: surname, username: username, email: email, phoneNumber: phoneNumber, password: password)
                    print("Registering...")
                    
                    
                }) {
                    Text("Register")
                        .padding()
                        .background(Color.black)
                        .foregroundColor(Color.spotifyGreen)
                        .cornerRadius(8)
                }
                .background(
                    NavigationLink(
                    destination: LoginView(isLoggedIn: $isLoggedIn),
                    isActive: $authManager.authenticationDidSucceed) { // Use the correct Binding here
                    EmptyView()
                }
                    .hidden() // Hide the NavigationLink
                )
            }
            .padding(.horizontal, 40)
        }
        .onReceive(authManager.$authenticationDidSucceed) { success in
            if success {
                self.shouldNavigateToLogin = true
            }
        }
    }
}


func register(authManager: AuthorizationManager, name: String, surname: String, username: String, email: String, phoneNumber: String, password: String) {
    guard let url = URL(string: "http://127.0.0.1:5000/register") else { return }
    
    let user_data: [String: Any] = [
        "name": name,
        "surname": surname,
        "username": username,
        "phone_number": phoneNumber
    ]
    
    
    let parameters: [String: Any] = [
        "email": email,
        "password": password,
        "user_data": user_data
    ]
    
    let data = try? JSONSerialization.data(withJSONObject: parameters)
    
    var request = URLRequest(url: url)
    request.httpMethod = "POST"
    request.httpBody = data
    request.addValue("application/json", forHTTPHeaderField: "Content-Type")
    
    URLSession.shared.dataTask(with: request) { data, response, error in
        if let error = error {
            print("Error: \(error.localizedDescription)")
            return
        }
        
        if let httpResponse = response as? HTTPURLResponse {
            print("HTTP Status Code: \(httpResponse.statusCode)")
            if httpResponse.statusCode == 200 {
                DispatchQueue.main.async {
                    // Find the current root view controller
                    if let rootViewController = UIApplication.shared.windows.first(where: { $0.isKeyWindow })?.rootViewController {
                        // Present the link account view controller
                        authManager.presentLinkAccountViewController(from: rootViewController)
                    }
                }
            }
        } else {
            print("Did not receive HTTPURLResponse")
        }
    }.resume() // Make sure this is being called

}

class AuthorizationManager: ObservableObject {
    @Published var authenticationDidSucceed: Bool = false
    func presentLinkAccountViewController(from viewController: UIViewController, completion: (() -> Void)? = nil) {
        let linkAccountVC = ViewController()  // Make sure this is the correct view controller you want to present
        viewController.present(linkAccountVC, animated: true){
            linkAccountVC.viewDidLoad()
        }
    }
}

struct RegisterView_Previews: PreviewProvider {
    static var previews: some View {
        RegisterView(isLoggedIn: .constant(false))
    }
}

