//
//  NetworkError.swift
//  tune-mosaic
//
//  Created by Kaan Aras on 9.12.2023.
//

import Foundation

enum NetworkError: Error {
    case invalidURL
    case invalidServerResponse
    case generalError
}
