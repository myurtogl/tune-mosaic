//
//  AlbumsView.swift
//  tune-mosaic
//
//  Created by Kaan Aras on 11.12.2023.
//

import SwiftUI
import FirebaseAuth
import FirebaseDatabase

struct AlbumsView: View {
    @State private var albums: [String] = []

    var body: some View {
        NavigationView {
            List {
                ForEach(albums, id: \.self) { album in
                    Text(album)
                        .swipeActions {
                            Button(role: .destructive) {
                                deleteAlbum(album)
                            } label: {
                                Label("Delete", systemImage: "trash")
                            }
                        }
                }
            }
            .navigationTitle("Albums")
            .onAppear(perform: loadAlbums)
        }
    }

    private func loadAlbums() {
        // Updated to match new data structure
        guard let user = Auth.auth().currentUser else {
            print("No authenticated user found")
            return
        }

        let userId = user.uid
        let ref = Database.database().reference(withPath: "users/\(userId)/songs")

        ref.observeSingleEvent(of: .value) { snapshot in
            var newAlbums = Set<String>()
            
            for child in snapshot.children {
                if let snapshot = child as? DataSnapshot,
                   let songDict = snapshot.value as? [String: AnyObject],
                   let album = songDict["Album"] as? String {
                    newAlbums.insert(album)
                }
            }
            
            DispatchQueue.main.async {
                self.albums = Array(newAlbums)
            }
        }
    }

    private func deleteAlbum(_ album: String) {
        // Updated to match new data structure
        guard let user = Auth.auth().currentUser else {
            print("No authenticated user found")
            return
        }

        let userId = user.uid
        let ref = Database.database().reference(withPath: "users/\(userId)/songs")

        ref.observeSingleEvent(of: .value) { snapshot in
            let group = DispatchGroup()
            
            for child in snapshot.children {
                group.enter()
                if let snapshot = child as? DataSnapshot,
                   let songDict = snapshot.value as? [String: AnyObject],
                   let albumName = songDict["Album"] as? String,
                   albumName == album {
                    ref.child(snapshot.key).removeValue { error, _ in
                        group.leave()
                        if let error = error {
                            print("Error deleting song: \(error.localizedDescription)")
                        }
                    }
                } else {
                    group.leave()
                }
            }
            
            group.notify(queue: .main) {
                self.loadAlbums() // Reload albums after deletion is complete
            }
        }
    }
}
