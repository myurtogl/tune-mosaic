import SwiftUI
import Foundation
import FirebaseAuth
import FirebaseDatabase

struct MainFeedView: View {
    let currentUserProfile: UserProfile
    @State var songs: [SongRecommendation] = []
    @State private var inputYears: String = "" // State for user input
    @State private var selectedPerformer: String = ""
    @State private var performers: [String] = []
    @State private var performerSongCounts: [String: Int] = [:]
    @State private var navigateToSongRecommendations = false

    var body: some View {
            NavigationView {
                VStack {
                    // Top section with user profile and Fetch Songs button
                    HStack {
                        Button("Fetch Songs") {
                            fetchTopRatedSongs()
                        }
                        .foregroundColor(.white)
                        .background(Color.blue)
                        .cornerRadius(3)
                        Spacer()
                        userProfileLink
                    }
                    .padding(.horizontal)

                    // Input for number of years
                    TextField("Enter number of years", text: $inputYears)
                        .keyboardType(.numberPad) // Show number pad for input
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .padding()

                    // Performers Picker
                    Picker("Select a Performer", selection: $selectedPerformer) {
                        ForEach(performers, id: \.self) { performer in
                            Text(performer).tag(performer)
                        }
                    }
                    .pickerStyle(MenuPickerStyle())
                    .padding()

                    // Display the song count for the selected performer
                    if !selectedPerformer.isEmpty {
                        Text("Number of songs for \(selectedPerformer): \(performerSongCounts[selectedPerformer, default: 0])")
                            .padding()
                    }

                    // Spacer to push everything to the top
                    Spacer()

                    // List of songs
                    List {
                        ForEach($songs.indices, id: \.self) { index in
                            SongRowView(song: $songs[index])
                        }
                    }
                    
                    // Navigation buttons to Friends and Groups
                    HStack {
                        NavigationButtonView(title: "Groups", systemImageName: "person.3.fill", destination: GroupsView())
                        NavigationButtonView(title: "Friends", systemImageName: "person.2.fill", destination: FriendshipView(userProfile: currentUserProfile))
                    }
                    .padding(.horizontal)
    
                    // Bottom button for song recommendations
                    Button(action: {
                        self.navigateToSongRecommendations = true
                    }) {
                        Text("View Song Recommendations")
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.blue)
                            .cornerRadius(10)
                            .padding(.horizontal)
                    }
                    .background(
                        NavigationLink(
                            destination: SongRecommendationsView(), // Specify your destination view here
                            isActive: $navigateToSongRecommendations
                        ) {
                            EmptyView()
                        }
                        .hidden()
                    )
                }
                .navigationBarTitle("Top 10 Songs")
                .onAppear {
                    fetchPerformersAndSongCounts()
                }
            }
        }
    
    // A reusable view for navigation buttons
    struct NavigationButtonView<Destination: View>: View {
        var title: String
        var systemImageName: String
        var destination: Destination
        
        var body: some View {
            NavigationLink(destination: self.destination) {
                HStack {
                    Image(systemName: systemImageName)
                    Text(title)
                }
                .frame(minWidth: 0, maxWidth: .infinity)
                .padding()
                .foregroundColor(.white)
                .background(Color.blue)
                .cornerRadius(10)
            }
        }
    }
    

    // MARK: - User Profile Link View
    private var userProfileLink: some View {
        HStack {
            NavigationLink(destination: FriendshipView(userProfile: currentUserProfile)) {
            }

            Spacer()

            NavigationLink(destination: UserProfileView(isLoggedIn: .constant(true), user: currentUserProfile, newPostHandler: {})) {
                if let imageUrl = URL(string: currentUserProfile.profilePicture), let imageData = try? Data(contentsOf: imageUrl), let uiImage = UIImage(data: imageData) {
                    Image(uiImage: uiImage)
                        .resizable()
                        .scaledToFill()
                        .frame(width: 36, height: 36)
                        .clipShape(Circle())
                } else {
                    Image(systemName: "person.crop.circle.fill")
                        .resizable()
                        .scaledToFill()
                        .frame(width: 36, height: 36)
                        .background(Color.gray)
                        .clipShape(Circle())
                }
            }
        }
    }

    // MARK: - Fetch Top Rated Songs Function
    private func fetchTopRatedSongs() {
           guard let user = Auth.auth().currentUser else {
               print("No authenticated user found")
               return
           }
           
           guard let years = Int(inputYears), years > 0 else {
                       print("Invalid number of years")
                       return
                   }
           
           let userId = user.uid
           //let years = 50
           
           let urlString = "http://127.0.0.1:5000/top-songs?user_id=\(userId)&years=\(years)"
           if let url = URL(string: urlString) {
               URLSession.shared.dataTask(with: url) { data, response, error in
                   if let data = data {
                       do {
                           if let dictionary = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any],
                              let topSongIds = dictionary["top_song_ids"] as? [String] {
                               var fetchedSongs = [SongRecommendation]()
                               let group = DispatchGroup()
                               
                               for songId in topSongIds {
                                   group.enter()
                                   self.fetchSongData(userId: userId, songId: songId) { song in
                                       if let song = song {
                                           fetchedSongs.append(song)
                                       }
                                       group.leave()
                                   }
                               }
                               
                               group.notify(queue: .main) {
                                   self.songs = fetchedSongs.sorted { $0.id < $1.id }
                               }
                               
                           }
                       } catch {
                           print("Error decoding JSON: \(error)")
                       }
                   }
               }.resume()
           }
       }
    
    // MARK: - Fetch Song Data Function
    private func fetchSongData(userId: String, songId: String, completion: @escaping (SongRecommendation?) -> Void) {
        let ref = Database.database().reference().child("users").child(userId).child("songs").child(songId)
        
        ref.observeSingleEvent(of: .value, with: { snapshot in
            guard let value = snapshot.value as? [String: Any] else {
                print("Song not found")
                completion(nil)
                return
            }
            
            guard let name = value["Name"] as? String,
                  let artist = value["Artist"] as? String,
                  let album = value["Album"] as? String,
                  let genre = value["Genre"] as? String,
                  let releaseDate = value["Release Date"] as? String,
                  let durationMs = value["Duration (ms)"] as? Int,
                  let previewURL = value["Preview URL"] as? String,
                  let danceability = value["Danceability"] as? Double,
                  let energy = value["Energy"] as? Double,
                  let valence = value["Valence"] as? Double,
                  let rating = value["rating"] as? Int,
                  let dateOfRating = value["dateOfRating"] as? String else {
                print("Could not parse song data")
                completion(nil)
                return
            }
            
            let song = SongRecommendation(
                id: songId,
                Name: name,
                Artist: artist,
                Album: album,
                Genre: genre,
                ReleaseDate: releaseDate,
                DurationMs: durationMs,
                PreviewURL: previewURL,
                Danceability: danceability,
                Energy: energy,
                Valence: valence,
                rating: rating,
                dateOfRating: dateOfRating
            )
            
            completion(song)
            
        }) { error in
            print(error.localizedDescription)
            completion(nil)
        }
    }

    // MARK: - Fetch Performers And Song Counts Function
    private func fetchPerformersAndSongCounts() {
           guard let user = Auth.auth().currentUser else {
               print("No authenticated user found")
               return
           }
           
           let userId = user.uid
              let ref = Database.database().reference().child("users").child(userId).child("songs")
              ref.observeSingleEvent(of: .value) { snapshot in
                  var counts: [String: Int] = [:]
                  let songsSnapshot = snapshot.children.allObjects as? [DataSnapshot] ?? []

                  for songSnapshot in songsSnapshot {
                      if let songData = songSnapshot.value as? [String: Any],
                         let artist = songData["Artist"] as? String {
                          counts[artist, default: 0] += 1
                      }
                  }

                  DispatchQueue.main.async {
                      self.performers = Array(counts.keys).sorted()
                      self.performerSongCounts = counts
                      self.selectedPerformer = self.performers.first ?? ""
                  }
              }
          }
}

// MARK: - FilledButtonStyle
struct FilledButtonStyle: ButtonStyle {
    func makeBody(configuration: Self.Configuration) -> some View {
        configuration.label
            .foregroundColor(.white)
            .padding()
            .background(Color.blue)
            .cornerRadius(8)
            .scaleEffect(configuration.isPressed ? 0.95 : 1.0)
    }
}

// MARK: - SongRow View
struct SongRowView: View {
    @Binding var song: SongRecommendation

    var body: some View {
        VStack(alignment: .leading) {
            Text("Song: \(song.Name)")
                .font(.headline)
            Text("Artist: \(song.Artist)")
                .font(.subheadline)
            
            HStack {
                ForEach(1...5, id: \.self) { rating in
                    Image(systemName: song.rating >= rating ? "star.fill" : "star")
                        .foregroundColor(song.rating >= rating ? .yellow : .gray)
                        .onTapGesture {
                            // Update the rating using the index
                            self.song.rating = rating
                        }
                }
            }
        }
        .padding()
    }
}


// MARK: - RatingView Component
struct RatingView: View {
    @Binding var rating: Int
    
    var body: some View {
        HStack {
            ForEach(1...5, id: \.self) { number in
                Image(systemName: rating >= number ? "star.fill" : "star")
                    .foregroundColor(rating >= number ? .yellow : .gray)
            }
        }
    }
}

// MARK: - SongRecommendation Struct
struct SongRecommendation: Identifiable, Decodable {
    let id: String
    var Name: String
    var Artist: String
    var Album: String
    var Genre: String
    var ReleaseDate: String
    var DurationMs: Int
    var PreviewURL: String
    var Danceability: Double
    var Energy: Double
    var Valence: Double
    var rating: Int
    var dateOfRating: String
}

struct MainFeedView_Previews: PreviewProvider {
    static var previews: some View {
        MainFeedView(
            currentUserProfile: UserProfile(
                id: "c6MdQAEMxuSPC57mbZxA9JAkidw2",
                username: "umutdeser",
                email: "umut@deser.com",
                name: "Umut",
                surname: "Deser",
                profilePicture: "https://example.com/profile-picture.jpg"
            )
        )
    }
}
