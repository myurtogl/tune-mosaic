//
//  MainFeedView.swift
//  tune-mosaic
//
//  Created by Kaan Aras on 13.11.2023.
//

//
//  MainFeedView.swift
//  tune-mosaic
//
//  Created by Kaan Aras on 13.11.2023.
//

import SwiftUI
import Foundation
import FirebaseAuth
import FirebaseDatabase

struct MainFeedView: View {
    let currentUserProfile: UserProfile
    @State var songs: [SongRecommendation] = []
    @State private var inputYears: String = "" // State for user input
    @State private var selectedPerformer: String = ""
    @State private var performers: [String] = []
    @State private var performerSongCounts: [String: Int] = [:]

    var body: some View {
        NavigationView {
            VStack {
                TextField("Enter number of years", text: $inputYears)
                    .keyboardType(.numberPad) // Show number pad for input
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()
                
                // Performers Picker
                Picker("Select a Performer", selection: $selectedPerformer) {
                    ForEach(performers, id: \.self) { performer in
                        Text(performer).tag(performer)
                    }
                }
                .pickerStyle(MenuPickerStyle())
                .padding()

                // Display the song count for the selected performer
                if !selectedPerformer.isEmpty {
                    Text("Number of songs for \(selectedPerformer): \(performerSongCounts[selectedPerformer, default: 0])")
                        .padding()
                }

                List {
                    ForEach($songs.indices, id: \.self) { index in
                        VStack(alignment: .leading) {
                            Text("Song: \(songs[index].Name)")
                                .font(.headline)
                            Text("Artist: \(songs[index].Artist)")
                                .font(.subheadline)
                            
                            HStack {
                                ForEach(1...5, id: \.self) { rating in
                                    Image(systemName: songs[index].rating >= rating ? "star.fill" : "star")
                                        .foregroundColor(songs[index].rating >= rating ? .yellow : .gray)
                                        .onTapGesture {
                                            // Update the rating using the index
                                            self.songs[index].rating = rating
                                        }
                                }
                            }
                        }
                        .padding()
                    }
                }
                NavigationLink(destination: SongRecommendationsView()) {
                        Text("View Song Recommendations")
                    }
                    .padding()
            }
            .onAppear {
                fetchPerformersAndSongCounts()
            }
            .navigationBarTitle("Top 10 Songs")
            .navigationBarItems(trailing: Button(action: {
                // Call fetchTopRatedSongs when the button is pressed
                self.fetchTopRatedSongs()
            }) {
                Text("Fetch Songs")
            })
            .navigationBarTitle("Main Feed")
            .navigationBarItems(trailing: userProfileLink)
        }
    }
    
    // Helper method to create the user profile link
       private var userProfileLink: some View {
           NavigationLink(destination: UserProfileView(isLoggedIn: .constant(true), user: currentUserProfile, newPostHandler: {})) {
               Image(currentUserProfile.profilePicture)
                   .resizable()
                   .frame(width: 36, height: 36)
                   .clipShape(Circle())
           }
       }

    private func fetchTopRatedSongs() {
        guard let user = Auth.auth().currentUser else {
            print("No authenticated user found")
            return
        }
        
        guard let years = Int(inputYears), years > 0 else {
                    print("Invalid number of years")
                    return
                }
        
        let userId = user.uid
        //let years = 50
        
        let urlString = "http://127.0.0.1:5000/top-songs?user_id=\(userId)&years=\(years)"
        if let url = URL(string: urlString) {
            URLSession.shared.dataTask(with: url) { data, response, error in
                if let data = data {
                    do {
                        if let dictionary = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any],
                           let topSongIds = dictionary["top_song_ids"] as? [String] {
                            var fetchedSongs = [SongRecommendation]()
                            let group = DispatchGroup()
                            
                            for songId in topSongIds {
                                group.enter()
                                self.fetchSongData(userId: userId, songId: songId) { song in
                                    if let song = song {
                                        fetchedSongs.append(song)
                                    }
                                    group.leave()
                                }
                            }
                            
                            group.notify(queue: .main) {
                                self.songs = fetchedSongs.sorted { $0.id < $1.id }
                            }
                            
                        }
                    } catch {
                        print("Error decoding JSON: \(error)")
                    }
                }
            }.resume()
        }
    }
    
    private func fetchPerformersAndSongCounts() {
        guard let user = Auth.auth().currentUser else {
            print("No authenticated user found")
            return
        }
        
        let userId = user.uid
           let ref = Database.database().reference().child("users").child(userId).child("songs")
           ref.observeSingleEvent(of: .value) { snapshot in
               var counts: [String: Int] = [:]
               let songsSnapshot = snapshot.children.allObjects as? [DataSnapshot] ?? []

               for songSnapshot in songsSnapshot {
                   if let songData = songSnapshot.value as? [String: Any],
                      let artist = songData["Artist"] as? String {
                       counts[artist, default: 0] += 1
                   }
               }

               DispatchQueue.main.async {
                   self.performers = Array(counts.keys).sorted()
                   self.performerSongCounts = counts
                   self.selectedPerformer = self.performers.first ?? ""
               }
           }
       }
    
    func fetchSongData(userId: String, songId: String, completion: @escaping (SongRecommendation?) -> Void) {
        let ref = Database.database().reference().child("users").child(userId).child("songs").child(songId)
        ref.observeSingleEvent(of: .value) { snapshot in
            if let songData = snapshot.value as? [String: Any],
               let name = songData["Name"] as? String,
               let artist = songData["Artist"] as? String,
               let album = songData["Album"] as? String,
               let genre = songData["Genre"] as? String,
               let releaseDate = songData["Release Date"] as? String,
               let durationMs = songData["Duration (ms)"] as? Int,
               let previewURL = songData["Preview URL"] as? String,
               let danceability = songData["Danceability"] as? Double,
               let energy = songData["Energy"] as? Double,
               let valence = songData["Valence"] as? Double {
                let songRecommendation = SongRecommendation(
                    id: songId,
                    Name: name,
                    Artist: artist,
                    Album: album,
                    Genre: genre,
                    ReleaseDate: releaseDate,
                    DurationMs: durationMs,
                    PreviewURL: previewURL,
                    Danceability: danceability,
                    Energy: energy,
                    Valence: valence,
                    rating: songData["rating"] as? Int ?? 0,
                    dateOfRating: songData["dateOfRating"] as? String ?? "11-12-2023"
                )
                completion(songRecommendation)
            } else {
                completion(nil)
            }
        }
    }
}

struct SongRecommendation: Identifiable, Decodable {
    let id: String
    var Name: String
    var Artist: String
    var Album: String
    var Genre: String
    var ReleaseDate: String
    var DurationMs: Int
    var PreviewURL: String
    var Danceability: Double
    var Energy: Double
    var Valence: Double
    var rating: Int
    var dateOfRating: String
}

struct MainFeedView_Previews: PreviewProvider {
    static var previews: some View {
        MainFeedView(currentUserProfile: UserProfile(id: "1", username: "umutdeser", profilePicture: "0858e72e-bc03-43a7-9361-390354f7186d"))
    }
}

