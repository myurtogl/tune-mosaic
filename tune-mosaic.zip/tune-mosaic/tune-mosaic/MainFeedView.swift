//
//  MainFeedView.swift
//  tune-mosaic
//
//  Created by Kaan Aras on 13.11.2023.
//

import SwiftUI

struct MainFeedView: View {
    @State private var newPostText: String = "" // State for text input
    let currentUserProfile: UserProfile
    
    // Define an array of posts
    let posts: [MusicPost] = [
        MusicPost(id: "1", user: UserProfile(id: "2", username: "user2", profilePicture: "e3037347-2569-4ef1-ac48-3aeb8b0d8256"), songName: "Song 1", artistName: "Artist 1", likes: 120),
        MusicPost(id: "2", user: UserProfile(id: "3", username: "user3", profilePicture: "1f342f82-c8f7-4900-8cd8-904fce4cfa15"), songName: "Song 2", artistName: "Artist 2", likes: 85),
        MusicPost(id: "3", user: UserProfile(id: "4", username: "user4", profilePicture: "83b1144e-6242-4ab6-83c2-556f2bf1a905 2"), songName: "Song 3", artistName: "Artist 3", likes: 95),
        MusicPost(id: "4", user: UserProfile(id: "5", username: "user5", profilePicture: "335be4c7-1b1c-45f8-84a0-c4ab41e5c9e5"), songName: "Song 4", artistName: "Artist 4", likes: 75),
        MusicPost(id: "5", user: UserProfile(id: "6", username: "user6", profilePicture: "76bed728-7441-4ffc-8d1d-24e166dfa553"), songName: "Song 5", artistName: "Artist 5", likes: 200),
        MusicPost(id: "6", user: UserProfile(id: "7", username: "user7", profilePicture: "d790d1ee-25eb-412c-84a4-1107ad099135"), songName: "Song 6", artistName: "Artist 6", likes: 50)
    ]

    var body: some View {
        NavigationView {
            List {
                Section(header: Text("Create New Post")) {
                    TextField("What's your favorite song?", text: $newPostText)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .padding()

                    Button("Add File") {
                        // Future implementation for file upload
                        print("File adding..")
                    }
                }

                ForEach(posts) { post in
                    MusicPostRow(post: post)
                }
            }
            .navigationBarItems(trailing: NavigationLink(destination: UserProfileView(user: currentUserProfile)) {
                Image(currentUserProfile.profilePicture) // Ensure this image exists in your Assets.xcassets
                    .resizable()
                    .frame(width: 36, height: 36)
                    .clipShape(Circle())
            })
            .navigationBarTitle("Feed")
        }
    }
}

struct MainFeedView_Previews: PreviewProvider {
    static var previews: some View {
        MainFeedView(currentUserProfile: UserProfile(id: "1", username: "currentuser", profilePicture: "0858e72e-bc03-43a7-9361-390354f7186d"))
    }
}
