//
//  LoginView.swift
//  tune-mosaic
//
//  Created by Kaan Aras on 2.11.2023.
//

import SwiftUI

struct LoginView: View {
    @State private var usernameOrEmail: String = ""
    @State private var password: String = ""
    @State private var isPasswordVisible: Bool = false

    var body: some View {
        ZStack {
            Color.spotifyGreen
                .edgesIgnoringSafeArea(.all)
            
            VStack(spacing: 20) {
                TextField("Email or Username", text: $usernameOrEmail)
                    .autocapitalization(.none) // Start with lowercase
                    .padding()
                    .background(Color.white.opacity(0.1))
                    .cornerRadius(8)
                    .foregroundColor(.white)
                
                HStack {
                    if isPasswordVisible {
                        TextField("Password", text: $password)
                            .autocapitalization(.none) // Start with lowercase
                    } else {
                        SecureField("Password", text: $password)
                    }
                    Button(action: {
                        isPasswordVisible.toggle()
                    }) {
                        Image(systemName: isPasswordVisible ? "eye.slash.fill" : "eye.fill")
                            .foregroundColor(.white)
                    }
                }
                .padding()
                .background(Color.white.opacity(0.1))
                .cornerRadius(8)
                
                Button(action: {
                    // Handle login action here
                    login(usernameOrEmail: usernameOrEmail, password: password)
                    print("Logging in with \(usernameOrEmail) and \(password)")
                }) {
                    Text("Login")
                        .padding()
                        .background(Color.black)
                        .foregroundColor(Color.spotifyGreen)
                        .cornerRadius(8)
                        .padding(.vertical, 10)
                }
            }
            .padding(.horizontal, 40)
        }
    }
}


#Preview {
    LoginView()
}

func login(usernameOrEmail: String, password: String) {
    guard let url = URL(string: "YOUR_FLASK_BACKEND_URL/login") else { return }
    
    let parameters: [String: Any] = [
        "email": usernameOrEmail,  // Your backend might require just "email" or both "email" and "username"
        "password": password
    ]

    let data = try? JSONSerialization.data(withJSONObject: parameters)
    
    var request = URLRequest(url: url)
    request.httpMethod = "POST"
    request.httpBody = data
    request.addValue("application/json", forHTTPHeaderField: "Content-Type")
    
    URLSession.shared.dataTask(with: request) { data, response, error in
        if let error = error {
            // Handle error here
            print("Error: \(error)")
            return
        }
        
        // Handle response here
        if let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 {
            // Successful login, handle accordingly
        } else {
            // Handle failure
        }
    }.resume()
}
