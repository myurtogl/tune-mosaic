//
//  LoginView.swift
//  tune-mosaic
//
//  Created by Kaan Aras on 2.11.2023.
//

import SwiftUI
import FirebaseAuth
import FirebaseCore
import GoogleSignIn



struct LoginView: View {
    @State private var usernameOrEmail: String = ""
    @State private var password: String = ""
    @State private var isPasswordVisible: Bool = false
    @Binding var isLoggedIn: Bool

    var body: some View {
        ZStack {
            Color.spotifyGreen
                .edgesIgnoringSafeArea(.all)
            
            VStack(spacing: 20) {
                TextField("Email or Username", text: $usernameOrEmail)
                    .autocapitalization(.none) // Start with lowercase
                    .padding()
                    .background(Color.white.opacity(0.1))
                    .cornerRadius(8)
                    .foregroundColor(.white)
                
                HStack {
                    if isPasswordVisible {
                        TextField("Password", text: $password)
                            .autocapitalization(.none) // Start with lowercase
                    } else {
                        SecureField("Password", text: $password)
                    }
                    Button(action: {
                        isPasswordVisible.toggle()
                    }) {
                        Image(systemName: isPasswordVisible ? "eye.slash.fill" : "eye.fill")
                            .foregroundColor(.white)
                    }
                    
                }
                .padding()
                .background(Color.white.opacity(0.1))
                .cornerRadius(8)
                
                Button(action: {
                    signInAndVerifyToken(email: usernameOrEmail, password: password)
                }) {
                    Text("Login")
                        .padding()
                        .background(Color.black)
                        .foregroundColor(Color.spotifyGreen)
                        .cornerRadius(8)
                }
                .padding(.top, 20) // Add padding if necessary to space it from the login button
            }
            .padding(.horizontal, 40)
        }
    }
    
    

    func signInAndVerifyToken(email: String, password: String) {
        Auth.auth().signIn(withEmail: email, password: password) { authResult, error in
            if let error = error {
                print("Error signing in: \(error)")
                return
            }

            authResult?.user.getIDToken(completion: { (token, error) in
                if let error = error {
                    print("Error getting token: \(error)")
                    return
                }

                if let token = token {
                    verifyTokenWithBackend(token: token) { success in
                        DispatchQueue.main.async {
                            isLoggedIn = success
                        }
                    }
                }
            })
        }
    }

    func verifyTokenWithBackend(token: String, completion: @escaping (Bool) -> Void) {
        guard let url = URL(string: "http://127.0.0.1:5000/verify-token") else { return }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")

        let body: [String: Any] = ["token": token]
        request.httpBody = try? JSONSerialization.data(withJSONObject: body, options: [])

        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Network error: \(error)")
                completion(false)
                return
            }
            if let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 {
                completion(true)
                // Inside your LoginView, after a successful login:
                isLoggedIn = true

            } else {
                completion(false)
            }
        }.resume()
    }
}

struct LoginView_Previews: PreviewProvider {
    static var previews: some View {
        LoginView(isLoggedIn: .constant(false))
    }
}
