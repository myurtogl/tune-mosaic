//
//  tune-mosaic-Bridging-Header.h
//  tune-mosaic
//
//  Created by Kaan Aras on 8.12.2023.
//

#ifndef tune_mosaic_Bridging_Header_h
#define tune_mosaic_Bridging_Header_h

#import <SpotifyiOS/SpotifyiOS.h>


#endif /* tune_mosaic_Bridging_Header_h */
